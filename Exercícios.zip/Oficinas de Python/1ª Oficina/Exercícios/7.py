# EXERCÍCIO 7:

# Crie um programa que leia um número inteiro fornecido pelo usuário
# e mostre na tela seu antecessor e seu sucessor.
# Resposta final esperada: O antecessor de 5 é 4 e o sucessor é 6.

# Resolução:

n = int(input('Digite um número inteiro: '))
print(f'O antecessor de {n} é {n-1} e o sucessor é {n+1}.')
