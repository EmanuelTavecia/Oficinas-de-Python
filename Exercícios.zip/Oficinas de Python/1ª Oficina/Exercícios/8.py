# EXERCÍCIO 8:

# Crie um programa que converta minutos para segundos.

# Resolução:

n = int(input('Digite um número: '))
print(f'{n} minutos são {n * 60} segundos.')
