# EXERCÍCIO 9:

# Crie um programa que leia o
# comprimento e a largura e calcule a área.

# Resolução:

c = float(input('Digite o comprimento: '))
l = float(input('Digite a largura: '))
print(f'A área é {c*l}')
