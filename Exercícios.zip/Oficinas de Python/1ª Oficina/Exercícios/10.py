# EXERCÍCIO 10:

# Crie um programa que pergunte e exiba na tela
# seu nome completo, sua cidade e sua idade.
# Para cada dado desse, crie uma variável apropriada.
# Exiba tudo na tela de forma organizada.
# Resposta final esperada:
# Emanuel, que mora na cidade de Araranguá, tem 16 anos.

# Resolução:

nome = input("Qual seu nome completo? ")
cidade = input("Qual sua cidade? ")
idade = float(input("Qual sua idade? "))
print(f'{nome}, que mora na cidade de {cidade}, tem {idade} anos.')
