# + adição
# - subtração
# * multiplicação
# / divisão
# ** potência
# // Divisão inteira
# % Resto da divisão