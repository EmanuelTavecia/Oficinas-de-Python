# EXERCÍCIO 1:

# Crie um programa em que o usuário digite um número inteiro
# e mostre na tela se ele é par ou ímpar.

# Resolução:

n = int(input('Digite um número: '))
if n % 2 == 0:
    print('É par!')
else:
    print('É ímpar!')
